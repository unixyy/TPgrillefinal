import java.util.ArrayList;

class HillClimbing {

    public static Solution hillClimbingWithRestart(IFactory f, int nbRestart) {


        //prérequis : nbRestart >= 1
        //effectue nbRestart fois l'algorithme de hillClimbing, en partant à chaque fois d'un élément donné par f

        //à compléter
        return null;
    }

    public static IElemHC hillClimbing(IElemHC s){


        //effectue une recherche locale en partant de s :
        // - en prenant à chaque étape le meilleur des voisins de la solution courante (ou un des meilleurs si il y a plusieurs ex aequo)
        // - en s'arrêtant dès que la solution courante n'a pas de voisin strictement meilleur qu'elle
        // (meilleur au sens de getVal strictement plus grand)

        // à compléter
       return null;
    }
}